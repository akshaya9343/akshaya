def qa_prompt(question: str) -> str:
    return f"""
You are EduGenie, a friendly educational assistant.
Answer the student's question accurately and concisely.

Question:
{question}

Rules:
- Explain in simple language.
- Use short paragraphs or bullets when useful.
- If the question is ambiguous, state the assumption you are making.
- Do not invent sources, citations, statistics, or facts.
- End with one short "Key takeaway:" sentence.
""".strip()


def summary_prompt(text: str) -> str:
    return f"""
Summarize the educational passage below for a student.

Requirements:
- Preserve the important facts and meaning.
- Remove repetition and unnecessary detail.
- Use simple language.
- Return a concise title followed by 4-8 bullet points.
- Do not add information that is not present in the passage.

Passage:
{text}
""".strip()


def quiz_prompt(text: str) -> str:
    return f"""
Create exactly 3 multiple-choice questions from the educational content below.

Return ONLY valid JSON. Do not wrap it in Markdown fences.
Use exactly this schema:
{{
  "questions": [
    {{
      "question": "string",
      "options": ["string", "string", "string", "string"],
      "correct_answer": "string",
      "explanation": "string"
    }}
  ]
}}

Rules:
- Exactly 3 questions.
- Exactly 4 options per question.
- correct_answer must exactly match one option.
- Questions must be answerable from the supplied content.
- Distractors should be plausible but clearly incorrect.
- Keep explanations short.

Content:
{text}
""".strip()


def learning_path_prompt(topic: str, level: str, goal: str) -> str:
    return f"""
Create a structured learning path for the topic "{topic}".

Learner level: {level}
Learning goal: {goal or "Build a solid understanding and practical ability."}

Include:
1. A short overview.
2. Beginner, intermediate, and advanced stages.
3. Topics in a sensible order.
4. Suggested time for each stage.
5. Practice activities or projects.
6. Useful resource types such as documentation, videos, articles, or books.
7. A simple way to check progress.

Keep it practical, readable, and appropriate for the learner level.
Do not invent specific URLs.
""".strip()


def explanation_prompt(topic: str) -> str:
    return f"""
Explain the following concept to a beginner: {topic}

Use:
- A simple definition.
- A step-by-step explanation.
- One everyday analogy.
- One small example.
- A short key takeaway.

Avoid unnecessary jargon.
""".strip()
