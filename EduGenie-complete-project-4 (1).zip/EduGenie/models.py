from pydantic import BaseModel, Field


class TextRequest(BaseModel):
    text: str = Field(..., min_length=3, max_length=20000)


class QARequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=5000)


class ExplainRequest(BaseModel):
    topic: str = Field(..., min_length=2, max_length=3000)


class QuizRequest(TextRequest):
    pass


class SummaryRequest(TextRequest):
    pass


class LearningPathRequest(BaseModel):
    topic: str = Field(..., min_length=2, max_length=1000)
    level: str = Field(default="beginner", max_length=50)
    goal: str = Field(default="", max_length=1000)
