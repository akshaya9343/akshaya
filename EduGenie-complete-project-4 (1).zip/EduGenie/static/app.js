const task = document.getElementById("task");
const inputText = document.getElementById("inputText");
const inputLabel = document.getElementById("inputLabel");
const levelWrap = document.getElementById("levelWrap");
const level = document.getElementById("level");
const goal = document.getElementById("goal");
const submitBtn = document.getElementById("submitBtn");
const result = document.getElementById("result");
const copyBtn = document.getElementById("copyBtn");
const statusEl = document.getElementById("status");

let lastResultText = "";

const taskConfig = {
  qa: {
    label: "Your question",
    placeholder: "Example: Which is the largest ocean?",
  },
  explain: {
    label: "Concept to explain",
    placeholder: "Example: Explain the Pythagoras theorem",
  },
  quiz: {
    label: "Topic or passage",
    placeholder: "Paste a topic or educational passage here...",
  },
  summarize: {
    label: "Text to summarize",
    placeholder: "Paste a long educational passage here...",
  },
  learn: {
    label: "Topic to learn",
    placeholder: "Example: SQL",
  },
};

task.addEventListener("change", () => {
  const config = taskConfig[task.value];
  inputLabel.textContent = config.label;
  inputText.placeholder = config.placeholder;
  levelWrap.classList.toggle("hidden", task.value !== "learn");
});

function setLoading(isLoading) {
  submitBtn.disabled = isLoading;
  submitBtn.textContent = isLoading ? "Generating..." : "Generate";
  statusEl.textContent = isLoading ? "Working..." : "Ready";
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderQuiz(quiz) {
  const questions = quiz.questions || [];
  result.classList.remove("empty");
  result.innerHTML = questions.map((q, index) => `
    <div class="quiz-question">
      <h3>${index + 1}. ${escapeHtml(q.question)}</h3>
      ${q.options.map((option, optionIndex) => `
        <label class="quiz-option">
          <input type="radio" name="q${index}" value="${escapeHtml(option)}">
          ${escapeHtml(option)}
        </label>
      `).join("")}
      <div class="quiz-feedback" id="feedback-${index}"></div>
      <button class="secondary check-answer" data-index="${index}"
        data-correct="${escapeHtml(q.correct_answer)}"
        data-explanation="${escapeHtml(q.explanation)}">Check answer</button>
    </div>
  `).join("");

  document.querySelectorAll(".check-answer").forEach(btn => {
    btn.addEventListener("click", () => {
      const index = btn.dataset.index;
      const selected = document.querySelector(`input[name="q${index}"]:checked`);
      const feedback = document.getElementById(`feedback-${index}`);

      if (!selected) {
        feedback.textContent = "Choose an option first.";
        return;
      }

      if (selected.value === btn.dataset.correct) {
        feedback.textContent = "Correct! " + btn.dataset.explanation;
      } else {
        feedback.textContent =
          `Not quite. Correct answer: ${btn.dataset.correct}. ${btn.dataset.explanation}`;
      }
    });
  });

  lastResultText = questions.map((q, i) =>
    `${i + 1}. ${q.question}\n- ${q.options.join("\n- ")}\nCorrect: ${q.correct_answer}\n${q.explanation}`
  ).join("\n\n");
  copyBtn.disabled = false;
}

async function submitTask() {
  const value = inputText.value.trim();

  if (!value) {
    result.classList.remove("empty");
    result.textContent = "Please enter some content first.";
    return;
  }

  setLoading(true);
  result.classList.remove("empty");
  result.textContent = "Generating your learning response...";
  copyBtn.disabled = true;

  let endpoint;
  let payload;

  if (task.value === "qa") {
    endpoint = "/qa";
    payload = { question: value };
  } else if (task.value === "explain") {
    endpoint = "/explain";
    payload = { topic: value };
  } else if (task.value === "quiz") {
    endpoint = "/quiz";
    payload = { text: value };
  } else if (task.value === "summarize") {
    endpoint = "/summarize";
    payload = { text: value };
  } else {
    endpoint = "/learn/recommendations";
    payload = { topic: value, level: level.value, goal: goal.value.trim() };
  }

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.detail || "Request failed.");
    }

    if (task.value === "quiz") {
      renderQuiz(data.result);
    } else {
      lastResultText = data.result;
      result.textContent = data.result;
      copyBtn.disabled = false;
    }

    statusEl.textContent = "Done";
  } catch (error) {
    result.textContent = error.message;
    statusEl.textContent = "Error";
  } finally {
    setLoading(false);
  }
}

submitBtn.addEventListener("click", submitTask);

copyBtn.addEventListener("click", async () => {
  if (!lastResultText) return;
  await navigator.clipboard.writeText(lastResultText);
  statusEl.textContent = "Copied";
  setTimeout(() => statusEl.textContent = "Ready", 1200);
});

inputText.addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
    submitTask();
  }
});
