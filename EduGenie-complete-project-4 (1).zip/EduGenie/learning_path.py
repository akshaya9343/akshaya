from gemini_client import generate_text
from prompts import learning_path_prompt


async def get_learning_recommendations(
    topic: str,
    level: str = "beginner",
    goal: str = "",
) -> str:
    return generate_text(learning_path_prompt(topic, level, goal))
