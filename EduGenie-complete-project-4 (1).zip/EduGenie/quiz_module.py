import json
import re
from typing import Any

from gemini_client import generate_text
from prompts import quiz_prompt


def clean_json_block(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def validate_quiz(data: Any) -> dict:
    if not isinstance(data, dict) or not isinstance(data.get("questions"), list):
        raise ValueError("Quiz response must contain a 'questions' list.")

    questions = data["questions"]
    if len(questions) != 3:
        raise ValueError("Quiz must contain exactly 3 questions.")

    for item in questions:
        if not isinstance(item, dict):
            raise ValueError("Each question must be an object.")
        required = {"question", "options", "correct_answer", "explanation"}
        if not required.issubset(item):
            raise ValueError("A question is missing a required field.")
        if not isinstance(item["options"], list) or len(item["options"]) != 4:
            raise ValueError("Each question must have exactly 4 options.")
        if item["correct_answer"] not in item["options"]:
            raise ValueError("correct_answer must match one of the options.")

    return data


async def generate_quiz(text: str) -> dict:
    raw = generate_text(quiz_prompt(text))
    cleaned = clean_json_block(raw)

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Gemini returned invalid JSON: {exc}") from exc

    return validate_quiz(data)
