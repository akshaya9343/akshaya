from functools import lru_cache

from config import settings
from gemini_client import generate_text
from prompts import explanation_prompt


@lru_cache(maxsize=1)
def _load_local_pipeline():
    try:
        from transformers import pipeline
    except ImportError as exc:
        raise RuntimeError(
            "Local explanation requires transformers and torch. "
            "Install the full requirements.txt."
        ) from exc

    return pipeline(
        "text2text-generation",
        model=settings.local_explanation_model,
    )


async def explain_concept(topic: str) -> str:
    if settings.explanation_provider == "local":
        pipe = _load_local_pipeline()
        prompt = explanation_prompt(topic)
        result = pipe(
            prompt,
            max_new_tokens=300,
            do_sample=False,
        )
        return result[0]["generated_text"].strip()

    return generate_text(explanation_prompt(topic))
