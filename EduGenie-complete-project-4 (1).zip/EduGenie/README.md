# EduGenie: Google Gemini Powered Learning Assistant

EduGenie is a FastAPI + HTML/CSS/JavaScript educational assistant based on the supplied project documentation.

## Features

- Question answering through Gemini
- Beginner-friendly concept explanations
- 3-question MCQ quiz generation with 4 options per question
- Educational text summarization
- Beginner/intermediate/advanced learning paths
- Responsive single-page frontend
- REST API endpoints
- Optional local LaMini-Flan-T5-783M explanation provider

## Project structure

```text
EduGenie/
├── main.py
├── config.py
├── gemini_client.py
├── prompts.py
├── models.py
├── qna.py
├── explanation_module.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── app.js
│   └── style.css
└── tests/
    └── test_app.py
```

## 1. Install Python

Use Python 3.10 or newer.

Check:

```bash
python --version
```

On some systems use:

```bash
python3 --version
```

## 2. Open the project in VS Code

Open the `EduGenie` folder.

## 3. Create a virtual environment

Windows:

```powershell
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 4. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 5. Create your environment file

Copy `.env.example` to `.env`.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

macOS/Linux:

```bash
cp .env.example .env
```

Then open `.env` and replace:

```text
GEMINI_API_KEY=PASTE_YOUR_GEMINI_API_KEY_HERE
```

with your real Gemini API key.

Do not upload `.env` to GitHub. It is already ignored by `.gitignore`.

## 6. Choose the explanation provider

Default:

```text
EXPLANATION_PROVIDER=gemini
```

This keeps setup simple and uses Gemini for all five learning features.

The documentation also specifies a local LaMini-Flan-T5-783M explanation module. To use that implementation instead:

```text
EXPLANATION_PROVIDER=local
LOCAL_EXPLANATION_MODEL=MBZUAI/LaMini-Flan-T5-783M
```

The first local-model run downloads the model from Hugging Face and needs several GB of disk space. Gemini mode is recommended for the first successful demo.

## 7. Run the application

```bash
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

## 8. Test the API

Health check:

```bash
curl http://127.0.0.1:8000/health
```

Question answering:

```bash
curl -X POST http://127.0.0.1:8000/qa ^
  -H "Content-Type: application/json" ^
  -d "{\"question\":\"What is photosynthesis?\"}"
```

For macOS/Linux, use:

```bash
curl -X POST http://127.0.0.1:8000/qa \
  -H "Content-Type: application/json" \
  -d '{"question":"What is photosynthesis?"}'
```

## 9. Run automated tests

Install pytest if it is not already available:

```bash
pip install pytest
```

Then:

```bash
pytest -q
```

These tests cover the page, health endpoint, and request validation without requiring a live Gemini generation call.

## API endpoints

| Endpoint | Method | Purpose |
|---|---|---|
| `/` | GET | Web interface |
| `/health` | GET | Application health/configuration |
| `/qa` | POST | Question answering |
| `/explain` | POST | Concept explanation |
| `/quiz` | POST | 3-question MCQ generation |
| `/summarize` | POST | Passage summarization |
| `/learn/recommendations` | POST | Structured learning path |

## Notes

The supplied documentation describes Gemini 1.5 Pro. The code makes the Gemini model configurable through `GEMINI_MODEL`, so the project can use a currently available Gemini model without changing Python code.

The supplied documentation describes LaMini-Flan-T5-783M as a local explanation model. This project keeps that option available but uses Gemini by default so the first local demo does not require a multi-GB model download.

Never expose your Gemini API key in frontend JavaScript, HTML, GitHub, or screenshots.
